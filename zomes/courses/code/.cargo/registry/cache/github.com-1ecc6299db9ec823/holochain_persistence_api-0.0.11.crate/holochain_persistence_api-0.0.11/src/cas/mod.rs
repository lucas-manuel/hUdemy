//! This module contains trait definitions, examples, and test suites for AddressableContent
//! and ContentAddressableStorage.

pub mod content;
pub mod storage;
